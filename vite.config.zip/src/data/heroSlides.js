export const heroSlidesDesktop = [
  { id: 1, label: 'Wildlife and travel photograph by Indranil Chakravorty',           image: 'https://images.framedbyabard.com/cdn-cgi/image/format=auto/Desktop/Hero/hero1.jpg' },
  { id: 2, label: 'Wildlife and travel photograph by Indranil Chakravorty',  image: 'https://images.framedbyabard.com/cdn-cgi/image/format=auto/Desktop/Hero/hero2.jpg' },
  { id: 3, label: 'Wildlife and travel photograph by Indranil Chakravorty',         image: 'https://images.framedbyabard.com/cdn-cgi/image/format=auto/Desktop/Hero/hero3.jpg' },
  { id: 4, label: 'Wildlife and travel photograph by Indranil Chakravorty', image: 'https://images.framedbyabard.com/cdn-cgi/image/format=auto/Desktop/Hero/hero4.jpg' },
  { id: 5, label: 'Wildlife and travel photograph by Indranil Chakravorty', image: 'https://images.framedbyabard.com/cdn-cgi/image/format=auto/Desktop/Hero/hero5.jpg' },
];

export const heroSlidesMobile = [
  { id: 1, label: 'Land of the Pharaohs', image: '/hero1.jpeg' },
  { id: 2, label: 'Visit to Greece',      image: '/hero2.jpeg' },
  { id: 3, label: 'Travel to Italy',      image: '/hero3.jpeg' },
  { id: 4, label: 'Vietnam & Beyond',     image: '/hero4.jpeg' },
  { id: 5, label: 'England',              image: '/hero5.jpeg' },  
];